﻿
namespace NataliaNagorka
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.animal = new System.Windows.Forms.PictureBox();
            this.lolipopdown = new System.Windows.Forms.PictureBox();
            this.ground = new System.Windows.Forms.PictureBox();
            this.lolipopup = new System.Windows.Forms.PictureBox();
            this.punkty = new System.Windows.Forms.Label();
            this.Czas_grania = new System.Windows.Forms.Timer(this.components);
            this.lolipop3 = new System.Windows.Forms.PictureBox();
            this.lolipop1 = new System.Windows.Forms.PictureBox();
            this.lolipop2 = new System.Windows.Forms.PictureBox();
            this.lolipop4 = new System.Windows.Forms.PictureBox();
            this.kilknięcia = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.licznik = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.doggy = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.animal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipopdown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipopup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doggy)).BeginInit();
            this.SuspendLayout();
            // 
            // animal
            // 
            this.animal.BackColor = System.Drawing.Color.Transparent;
            this.animal.Image = global::NataliaNagorka.Properties.Resources.kiciabeztla1;
            this.animal.Location = new System.Drawing.Point(69, 92);
            this.animal.Name = "animal";
            this.animal.Size = new System.Drawing.Size(91, 95);
            this.animal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.animal.TabIndex = 0;
            this.animal.TabStop = false;
            // 
            // lolipopdown
            // 
            this.lolipopdown.BackColor = System.Drawing.Color.Transparent;
            this.lolipopdown.Image = global::NataliaNagorka.Properties.Resources.lizakbeztla;
            this.lolipopdown.Location = new System.Drawing.Point(224, 389);
            this.lolipopdown.Name = "lolipopdown";
            this.lolipopdown.Size = new System.Drawing.Size(100, 406);
            this.lolipopdown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lolipopdown.TabIndex = 1;
            this.lolipopdown.TabStop = false;
            // 
            // ground
            // 
            this.ground.BackColor = System.Drawing.Color.DarkOrchid;
            this.ground.Location = new System.Drawing.Point(-8, 525);
            this.ground.Name = "ground";
            this.ground.Size = new System.Drawing.Size(1574, 50);
            this.ground.TabIndex = 2;
            this.ground.TabStop = false;
            // 
            // lolipopup
            // 
            this.lolipopup.BackColor = System.Drawing.Color.Transparent;
            this.lolipopup.Image = global::NataliaNagorka.Properties.Resources.lizakbeztlanaodwrot;
            this.lolipopup.Location = new System.Drawing.Point(309, -254);
            this.lolipopup.Name = "lolipopup";
            this.lolipopup.Size = new System.Drawing.Size(100, 406);
            this.lolipopup.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lolipopup.TabIndex = 3;
            this.lolipopup.TabStop = false;
            // 
            // punkty
            // 
            this.punkty.AutoSize = true;
            this.punkty.BackColor = System.Drawing.Color.Transparent;
            this.punkty.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.punkty.ForeColor = System.Drawing.Color.Indigo;
            this.punkty.Location = new System.Drawing.Point(30, 9);
            this.punkty.Name = "punkty";
            this.punkty.Size = new System.Drawing.Size(130, 36);
            this.punkty.TabIndex = 4;
            this.punkty.Text = "Punkty: 0";
            // 
            // Czas_grania
            // 
            this.Czas_grania.Enabled = true;
            this.Czas_grania.Interval = 20;
            this.Czas_grania.Tick += new System.EventHandler(this.Czas_graniaEvent);
            // 
            // lolipop3
            // 
            this.lolipop3.BackColor = System.Drawing.Color.Transparent;
            this.lolipop3.Image = ((System.Drawing.Image)(resources.GetObject("lolipop3.Image")));
            this.lolipop3.Location = new System.Drawing.Point(753, 366);
            this.lolipop3.Name = "lolipop3";
            this.lolipop3.Size = new System.Drawing.Size(100, 406);
            this.lolipop3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lolipop3.TabIndex = 5;
            this.lolipop3.TabStop = false;
            // 
            // lolipop1
            // 
            this.lolipop1.BackColor = System.Drawing.Color.Transparent;
            this.lolipop1.Image = ((System.Drawing.Image)(resources.GetObject("lolipop1.Image")));
            this.lolipop1.Location = new System.Drawing.Point(455, 323);
            this.lolipop1.Name = "lolipop1";
            this.lolipop1.Size = new System.Drawing.Size(100, 406);
            this.lolipop1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lolipop1.TabIndex = 6;
            this.lolipop1.TabStop = false;
            // 
            // lolipop2
            // 
            this.lolipop2.BackColor = System.Drawing.Color.Transparent;
            this.lolipop2.Image = ((System.Drawing.Image)(resources.GetObject("lolipop2.Image")));
            this.lolipop2.Location = new System.Drawing.Point(610, -241);
            this.lolipop2.Name = "lolipop2";
            this.lolipop2.Size = new System.Drawing.Size(100, 406);
            this.lolipop2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lolipop2.TabIndex = 7;
            this.lolipop2.TabStop = false;
            // 
            // lolipop4
            // 
            this.lolipop4.BackColor = System.Drawing.Color.Transparent;
            this.lolipop4.Image = ((System.Drawing.Image)(resources.GetObject("lolipop4.Image")));
            this.lolipop4.Location = new System.Drawing.Point(868, -175);
            this.lolipop4.Name = "lolipop4";
            this.lolipop4.Size = new System.Drawing.Size(100, 406);
            this.lolipop4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lolipop4.TabIndex = 8;
            this.lolipop4.TabStop = false;
            // 
            // kilknięcia
            // 
            this.kilknięcia.AutoSize = true;
            this.kilknięcia.BackColor = System.Drawing.Color.Transparent;
            this.kilknięcia.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kilknięcia.ForeColor = System.Drawing.Color.Indigo;
            this.kilknięcia.Location = new System.Drawing.Point(33, 54);
            this.kilknięcia.Name = "kilknięcia";
            this.kilknięcia.Size = new System.Drawing.Size(147, 32);
            this.kilknięcia.TabIndex = 9;
            this.kilknięcia.Text = "Kliknięcia: 0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Magenta;
            this.label2.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(106, 533);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(792, 26);
            this.label2.TabIndex = 10;
            this.label2.Text = "Gra stworzona przez: Natalia Nagórka. Specjalne podziękowania dla Tomasza za nary" +
    "sowanie tekstur!";
            // 
            // licznik
            // 
            this.licznik.ForeColor = System.Drawing.Color.DarkMagenta;
            this.licznik.Location = new System.Drawing.Point(2, 496);
            this.licznik.Name = "licznik";
            this.licznik.Size = new System.Drawing.Size(212, 23);
            this.licznik.Step = 1;
            this.licznik.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(-1, 475);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 18);
            this.label1.TabIndex = 12;
            this.label1.Text = "Wyzwanie: Zdobądź 100pkt";
            // 
            // doggy
            // 
            this.doggy.BackColor = System.Drawing.Color.Transparent;
            this.doggy.Image = global::NataliaNagorka.Properties.Resources.piesekbeztla3;
            this.doggy.Location = new System.Drawing.Point(69, 92);
            this.doggy.Name = "doggy";
            this.doggy.Size = new System.Drawing.Size(91, 95);
            this.doggy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.doggy.TabIndex = 14;
            this.doggy.TabStop = false;
            // 
            // Form1
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(980, 568);
            this.Controls.Add(this.punkty);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.licznik);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.kilknięcia);
            this.Controls.Add(this.lolipop4);
            this.Controls.Add(this.ground);
            this.Controls.Add(this.lolipop2);
            this.Controls.Add(this.lolipop1);
            this.Controls.Add(this.lolipop3);
            this.Controls.Add(this.lolipopup);
            this.Controls.Add(this.lolipopdown);
            this.Controls.Add(this.animal);
            this.Controls.Add(this.doggy);
            this.Name = "Form1";
            this.Text = "Latające zwierzątka";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gamekeyisdown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gamekeyisup);
            ((System.ComponentModel.ISupportInitialize)(this.animal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipopdown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipopup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lolipop4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doggy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox animal;
        private System.Windows.Forms.PictureBox lolipopdown;
        private System.Windows.Forms.PictureBox ground;
        private System.Windows.Forms.PictureBox lolipopup;
        private System.Windows.Forms.Label punkty;
        private System.Windows.Forms.Timer Czas_grania;
        private System.Windows.Forms.PictureBox lolipop3;
        private System.Windows.Forms.PictureBox lolipop1;
        private System.Windows.Forms.PictureBox lolipop2;
        private System.Windows.Forms.PictureBox lolipop4;
        private System.Windows.Forms.Label kilknięcia;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar licznik;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox doggy;
    }
}

